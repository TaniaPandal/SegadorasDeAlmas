let colorList = [];
let coders = arregloCoders();
let myNodelist = document.getElementsByTagName("LI");

function limpiar() {

    document.location.reload();
}


function arregloCoders() {
    let lista = [...document.querySelectorAll(`li`)]
        .map(element => element.id);
    return (lista);
}

function verificarNombre(nombre) {

    if (coders.find(item => item === nombre)) {
        alert("No debe repetir un nombre");
    } else {
        return false;
    }
}

function capitalizacionNombre(nombre) {
    nombre = nombre.charAt(0).toUpperCase() + nombre.slice(1).toLowerCase();
    return nombre;
}

a
function nuevoCoder() {

    let li = document.createElement("li");
    let nombre = document.getElementById("entrada").value;
    nombre = capitalizacionNombre(nombre);
    let t = document.createTextNode(nombre);
    li.appendChild(t);
    if (nombre === '') {
        alert("Debe agregar un nombre");
    } else {
        if (verificarNombre(nombre) == false) {
            li.setAttribute("id", nombre);
            li.setAttribute("color", "white")
            document.getElementById("listado").appendChild(li);
            coders = arregloCoders();
            graficar(coders.length);
        }
    }

    document.getElementById("entrada").value = "";


}

var list = document.querySelector('ul');
list.addEventListener('click', function (ev) {
    if (ev.target.tagName === 'LI') {
        let chk = ev.target.classList.toggle('checked');
        coders = arregloCoders();
    }


}, false);
// eliminar nombres de la lista
function eliminarNombre() {
    const eliminar = document.getElementsByClassName('checked');
    while (eliminar.length > 0) {
        eliminar[0].parentNode.removeChild(eliminar[0]);
    }
    coders = arregloCoders();
}


function graficar(part) {

    const grados = 360;

    let nPart = grados / part;

    let arregloColores = generadorColor();
    let particiones = "conic-gradient(";
    let wheel = document.getElementById("wheel");

    let i = 0;
    let j = nPart;
    do {
        for (let x = 0; x < arregloColores.length; x++) {
            particiones += `${arregloColores[x]} ${i}deg , ${arregloColores[x]} ${j}deg ,`;
            i += nPart;
            j += nPart;


        }

    } while (i < grados)
    particiones = particiones.substring(0, particiones.length - 1);
    particiones += ")";
    console.log(particiones);

    wheel.style.backgroundImage = particiones;
    wheel.innerHTML;
}




function generadorColor() {

    r = Math.floor(Math.random() * (255));
    g = Math.floor(Math.random() * (255));
    b = Math.floor(Math.random() * (255));
    colorList.push(`rgb(${r},${g},${b})`);


    console.log(colorList);


    return colorList
}
